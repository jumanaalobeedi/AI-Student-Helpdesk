package models;

public class KnowledgeBase {
    // just so code compiles
}
